Pour lancer le programme il suffit de donner le path de son fichier en entrée, 
les solutions du problème pour SteepestHillClimbing et TabouSearch seront affichées.

lectF va ouvrir le fichier de path donné en entrée et rendre un tableau utilisable data.
solIni(data) initialise une solution aléatoire.
distSol(data,solution) donne la distance totale pour cette soliution.
SHCVar (data,solution) donne une solution avec SteepestHillClimbing avec redémarrage.
TabuSearch(data,solution) donne une solution avec l'algorithme Tabou Search.